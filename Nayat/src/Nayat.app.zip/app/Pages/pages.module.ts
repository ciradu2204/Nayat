import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { OtpComponent } from './otp/otp.component';
import { ProfileComponent } from './profile/profile.component';
import { RegistrationComponent } from './registration/registration.component';
import { ChatinterfaceComponent } from './chatinterface/chatinterface.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome'
 
import { CeComponentsModule } from '../ce-components/ce-components.module';
@NgModule({
  declarations: [ChatinterfaceComponent,LoginComponent,OtpComponent,ProfileComponent,RegistrationComponent],
  imports: [
    CommonModule,
    CeComponentsModule,
    AngularFontAwesomeModule
  ]
})
export class PagesModule { }
