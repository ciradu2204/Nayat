import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chatinterface',
  templateUrl: './chatinterface.component.html',
  styleUrls: ['./chatinterface.component.scss'],
})
export class ChatinterfaceComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
