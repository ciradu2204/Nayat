import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
})
export class ProfileComponent implements OnInit {
 
 
    
  constructor( ) { }
  
  
  showPopup() {
     var popup = document.getElementById('popup').style.display="block";
     document.getElementById('overlay').style.display="block";
   }

   closePopup(){
     var popup = document.getElementById('popup').style.display="none";
     document.getElementById('overlay').style.display="none";
   }
 
  ngOnInit() {}

}
