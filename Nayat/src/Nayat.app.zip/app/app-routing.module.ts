import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { CommonModule } from '@angular/common';
import {LoginComponent} from './Pages/login/login.component';
import { RegistrationComponent } from './Pages/registration/registration.component';
import { OtpComponent } from './Pages/otp/otp.component';
import { ProfileComponent } from './Pages/profile/profile.component';
import { ChatinterfaceComponent } from './Pages/chatinterface/chatinterface.component';
const routes: Routes = [
  {path:'',redirectTo:'login',pathMatch:'full'},
  {path:'login',component:LoginComponent},
  {path:'registration',component:RegistrationComponent},
  {path:'otp',component:OtpComponent},
  {path:'profile',component:ProfileComponent},
  {path:'chat',component:ChatinterfaceComponent}
];

@NgModule({
  imports: [

    CommonModule,RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
