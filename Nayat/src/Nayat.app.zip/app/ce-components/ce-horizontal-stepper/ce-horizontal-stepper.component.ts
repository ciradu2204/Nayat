import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ce-horizontal-stepper',
  templateUrl: './ce-horizontal-stepper.component.html',
  styleUrls: ['./ce-horizontal-stepper.component.scss']
})
export class CeHorizontalStepperComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}                 

