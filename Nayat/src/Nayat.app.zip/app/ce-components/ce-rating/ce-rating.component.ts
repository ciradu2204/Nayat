import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ce-rating',
  templateUrl: './ce-rating.component.html',
  styleUrls: ['./ce-rating.component.scss']
})
export class CeRatingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
