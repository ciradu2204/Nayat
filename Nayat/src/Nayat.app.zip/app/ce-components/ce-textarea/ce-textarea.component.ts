import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'ce-textarea',
  templateUrl: './ce-textarea.component.html',
  styleUrls: ['./ce-textarea.component.scss']
})
export class CeTextareaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
