import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ce-mood-select',
  templateUrl: './ce-mood-select.component.html',
  styleUrls: ['./ce-mood-select.component.scss']
})
export class CeMoodSelectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
