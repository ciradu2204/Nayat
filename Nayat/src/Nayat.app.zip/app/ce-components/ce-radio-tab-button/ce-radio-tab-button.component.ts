import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ce-radio-tab-button',
  templateUrl: './ce-radio-tab-button.component.html',
  styleUrls: ['./ce-radio-tab-button.component.scss']
})
export class CeRadioTabButtonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
