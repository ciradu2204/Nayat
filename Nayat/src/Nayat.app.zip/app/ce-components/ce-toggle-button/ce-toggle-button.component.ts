import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ce-toggle-button',
  templateUrl: './ce-toggle-button.component.html',
  styleUrls: ['./ce-toggle-button.component.scss']
})
export class CeToggleButtonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
