import { CeStringTemplateOutletDirective } from './ce-string-template-outlet.directive';

describe('CeStringTemplateOutletDirective', () => {
  it('should create an instance', () => {
    const directive = new CeStringTemplateOutletDirective();
    expect(directive).toBeTruthy();
  });
});
